
<?php
include 'databaseConnect.php'; // Include database connection file
include 'databaseLogin.php'; 

?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Producten</title>
    <link rel="stylesheet" href="producten.css">
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <header>
        <img src="logo.png" alt="Logo" class="logo">
        <nav>
            <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="producten.php">Producten</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="winkelwagen.php">winkelwagen</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section>
            <h2>Laptops</h2>
            <div>
                <img src="https://www.bing.com/th?id=OIP.sOdWXA8w_vNRtjpSjt6IdQHaFn&w=150&h=106&c=8&rs=1&qlt=90&o=6&dpr=1.8&pid=3.1&rm=2" alt="Foto" class="Foto">
                <h3>Samsung Laptop</h3>
                <p>Prijs: €100.99</p>
                <p>Beschrijving: CPU = Ryzen 5, RAM: 32 GB, SSD = 512 GB</p>
                <p>Afmetingen: 14 inch</p>
                <p>Gewicht: 1.5 kg</p>
                <form action="databaseConnect.php" method="post">
                    <input type="hidden" name="product_prijs" value="100.99">
                    <input type="hidden" name="product_name" value="Samsung Laptop">
                    <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>">
                    <button type="submit">Voeg toe aan winkelwagen</button>
                </form>
            </div>
        </section>
        
        <section>
            <h2>Smartphones</h2>
            <div>
                <img src="https://shop.samsung.com/ie/images/galaxy-z-fold2-5g-mystic-black-256-gb/11454/2000x2000/SM-F916BZKABTU.png" alt="Foto" class="Foto">
                <h3>Samsung Smartphone</h3>
                <p>Prijs: €113.99</p>
                <p>Beschrijving: color : pink</p>
                <form action="databaseConnect.php" method="post">
                    <input type="hidden" name="product_prijs" value="113.99">
                    <input type="hidden" name="product_name" value="Smartphones samsung">
                    <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>">
                    <button type="submit">Voeg toe aan winkelwagen</button>
                </form>
            </div>
            <div>
                <img src="https://images.frandroid.com/wp-content/uploads/2022/09/iphone-14-pro-max-officiel-frandroid-2022.png" alt="Foto" class="Foto">
                <h3>Apple Smartphone</h3>
                <p>Prijs: €144.99</p>
                <p>Beschrijving: color : black</p>
                <form action="databaseConnect.php" method="post">
                    <input type="hidden" name="product_prijs" value="144.99">
                    <input type="hidden" name="product_name" value="Smartphones Iphone">
                    <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>">
                    <button type="submit">Voeg toe aan winkelwagen</button>
                </form>
            </div>
        </section>

        <section>
            <h2>Smartwatches</h2>
            <div>
                <img src="https://www.androidcentral.com/sites/androidcentral.com/files/article_images/2019/02/galaxy-watch-collection.png?itok=3QOgWKi0" alt="Foto" class="Foto">
                <h3>Samsung Smartwatch</h3>
                <p>Prijs: €100.99</p>
                <p>Beschrijving: color : pink</p>
                <form action="databaseConnect.php" method="post">
                    <input type="hidden" name="product_prijs" value="100.99">
                    <input type="hidden" name="product_name" value="Samsung smartWatch">
                    <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>">
                    <button type="submit">Voeg toe aan winkelwagen</button>
                </form>
            </div>
            <div>
                <img src="https://www.pngarts.com/files/8/Apple-Watch-PNG-Transparent-Image.png" alt="Foto" class="Foto">
                <h3>Apple Smartwatch</h3>
                <p>Prijs: €14.99</p>
                <p>Beschrijving: color : black</p>
                <form action="databaseConnect.php" method="post">
                    <input type="hidden" name="product_prijs" value="14.99">
                    <input type="hidden" name="product_name" value="Iphone smartWatch">
                    <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>">
                    <button type="submit">Voeg toe aan winkelwagen</button>
                </form>
            </div>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2024 Webshop.</p>
    </footer>
</body>
</html>
