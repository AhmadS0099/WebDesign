<?php
include 'databaseConnect.php'; // Include database connection file
include 'databaseLogin.php'; 

?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Detail</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <header>
    <img src="logo.png" alt="Logo" class="logo">
        <nav>
        <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="producten.php">Producten</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="winkelwagen.php">winkelwagen</a></li>

            </ul>
        </nav>
    </header>
    
    <main>
        <section>
            <h2>Laptop</h2>
    
            <p>Prijs: €100.99</p>
            <p>Beschrijving: CPU = Ryzen 5, RAM: 32 GB, SSD = 512 GB</p>
            <p>Afmetingen: 14 inch</p>
            <p>Gewicht: 1.5 kg</p>
            <form action="databaseConnect.php" method="post">
                <input type="hidden" name="product_prijs" value="100.99"> <!-- Product Prijs -->
                <input type="hidden" name="product_name" value="Samsung Laptop"> <!-- Productnaam -->
                <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>"> <!-- Gebruikersnaam -->
                <button type="submit">Voeg toe aan winkelwagen</button>
            </form>

            <h2>samsung</h2>
            <p>Prijs: €144.99</p>
            <p>Beschrijving: color : pink</p>
            <form action="databaseConnect.php" method="post">
                <input type="hidden" name="product_prijs" value="144.99"> <!-- Product Prijs -->
                <input type="hidden" name="product_name" value="Smartphones Iphone"> <!-- Productnaam -->
                <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>"> <!-- Gebruikersnaam -->
                <button type="submit">Voeg toe aan winkelwagen</button>
            </form>
            

            <h2>Iphone</h2>
            <p>Prijs: €144.99</p>
            <p>Beschrijving: color : black</p>
            <form action="databaseConnect.php" method="post">
                <input type="hidden" name="product_prijs" value="144.99"> <!-- Product Prijs -->
                <input type="hidden" name="product_name" value="Smartphones samsung"> <!-- Productnaam -->
                <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>"> <!-- Gebruikersnaam -->
                <button type="submit">Voeg toe aan winkelwagen</button>
            </form>

            <h2>Iphone smartWatch</h2>
            <p>Prijs: €14.99</p>
            <p>Beschrijving: color : pink</p>
            <form action="databaseConnect.php" method="post">
                <input type="hidden" name="product_prijs" value="14.99"> <!-- Product Prijs -->
                <input type="hidden" name="product_name" value="Iphone smartWatch"> <!-- Productnaam -->
                <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>"> <!-- Gebruikersnaam -->
                <button type="submit">Voeg toe aan winkelwagen</button>
            </form>

            <h2>samsung smartWatch</h2>
            <p>Prijs: €14.99</p>
            <p>Beschrijving: color : black</p>
            <form action="databaseConnect.php" method="post">
                <input type="hidden" name="product_prijs" value="14.99"> <!-- Product Prijs -->
                <input type="hidden" name="product_name" value="Samsung smartWatch"> <!-- Productnaam -->
                <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>"> <!-- Gebruikersnaam -->
                <button type="submit">Voeg toe aan winkelwagen</button>
            </form>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2024 Webshop.</p>
    </footer>
</body>
</html>
