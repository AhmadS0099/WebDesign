<?php
session_start(); // Start a session to store user login status

include 'databaseConnect.php'; // Include database connection file

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // If the form submitted is for registration
    if (isset($_POST['register'])) {
        // Get username and password from the form
        $input_username = $_POST['username'];
        $input_password = $_POST['password'];

        // Validate inputs
        if (!empty($input_username) && !empty($input_password)) {
            // Prepare SQL query to insert new user into the 'tbllogin' table
            $sql = "INSERT INTO tbllogin (Name, PassWord) VALUES ('$input_username', '$input_password')";

            if ($conn->query($sql) === TRUE) {
                echo "Registration successful";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Username and password are required for registration";
        }
    } else { // If the form submitted is for login
        // Get username and password from the form
        $input_username = $_POST['username'];
        $input_password = $_POST['password'];

        // Validate inputs
        if (!empty($input_username) && !empty($input_password)) {
            // Prepare SQL query to fetch user with provided username and password
            $sql = "SELECT * FROM tbllogin WHERE Name='$input_username' AND PassWord='$input_password'";
            $result = $conn->query($sql);

            // Check if a user with provided credentials exists
            if ($result->num_rows == 1) {
                // User found, set session variables and redirect to homepage or any other page
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $input_username;
                $_SESSION['username'] = $input_username;
                header("Location: index.php"); // Redirect to homepage after successful login
                exit();
            } else {
                // No user found with provided credentials
                echo "Invalid username or password";
            }
        } else {
            echo "Username and password are required for login";
        }
    }
}
?>